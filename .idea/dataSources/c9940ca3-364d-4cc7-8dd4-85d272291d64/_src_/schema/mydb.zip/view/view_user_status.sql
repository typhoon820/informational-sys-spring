CREATE VIEW view_user_status AS
  SELECT
    `u`.`id`       AS `id`,
    `u`.`login`    AS `login`,
    `u`.`password` AS `password`,
    `us`.`status`  AS `status`
  FROM (`mydb`.`USER` `u`
    JOIN `mydb`.`USER_STATUS` `us` ON ((`u`.`status_id` = `us`.`id`)));
