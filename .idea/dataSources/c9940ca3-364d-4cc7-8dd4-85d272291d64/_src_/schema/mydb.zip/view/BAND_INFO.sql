CREATE VIEW BAND_INFO AS
  SELECT
    `a`.`ID`             AS `a_id`,
    `a`.`firstname`      AS `a_name`,
    `a`.`lastname`       AS `a_lastname`,
    `a`.`specialization` AS `a_specialization`,
    `ab`.`join_date`     AS `ab_joindate`,
    `ab`.`leave_date`    AS `ab_leavedate`,
    `b`.`ID`             AS `b_id`,
    `b`.`name`           AS `b_name`
  FROM ((`mydb`.`ARTIST` `a`
    JOIN `mydb`.`ARTIST_BAND` `ab` ON ((`a`.`ID` = `ab`.`ARTIST_ID`))) JOIN `mydb`.`BAND` `b`
      ON ((`ab`.`AUTHOR_ID` = `b`.`ID`)));
