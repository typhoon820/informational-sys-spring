CREATE VIEW song_info AS
  SELECT
    `s`.`ID`               AS `song_id`,
    `s`.`name`             AS `song_name`,
    `b`.`name`             AS `author_name`,
    `g`.`genre`            AS `song_genre`,
    `a`.`name`             AS `song_album`,
    `c`.`copies_available` AS `copies`,
    `sha`.`version`        AS `song_version`
  FROM ((((((`mydb`.`SONG` `s`
    JOIN `mydb`.`BAND` `b` ON ((`s`.`band_id` = `b`.`ID`))) JOIN `mydb`.`GENRE` `g`
      ON ((`s`.`genre_id` = `g`.`ID`))) JOIN `mydb`.`SONG_has_ALBUM` `sha` ON ((`sha`.`song_id` = `s`.`ID`))) JOIN
    `mydb`.`ALBUM` `a` ON ((`sha`.`album_id` = `a`.`ID`))) JOIN `mydb`.`CD_has_SONG` `chs`
      ON ((`s`.`ID` = `chs`.`SONG_ID`))) JOIN `mydb`.`CD` `c` ON ((`chs`.`CD_ID` = `c`.`ID`)));
