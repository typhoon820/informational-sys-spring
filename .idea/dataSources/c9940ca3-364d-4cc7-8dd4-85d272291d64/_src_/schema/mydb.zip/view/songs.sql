CREATE VIEW songs AS
  SELECT
    `s`.`ID`       AS `id`,
    `s`.`name`     AS `name`,
    `b`.`name`     AS `band`,
    `g`.`genre`    AS `genre`,
    `sa`.`version` AS `version`
  FROM (((`mydb`.`SONG` `s`
    JOIN `mydb`.`BAND` `b` ON ((`s`.`band_id` = `b`.`ID`))) JOIN `mydb`.`GENRE` `g`
      ON ((`s`.`genre_id` = `g`.`ID`))) JOIN `mydb`.`SONG_has_ALBUM` `sa` ON ((`s`.`ID` = `sa`.`song_id`)));
