CREATE PROCEDURE SaveNewUser(IN userName VARCHAR(64), IN pword VARCHAR(256), IN authorities VARCHAR(64))
  BEGIN 
    DECLARE auth_id INT;
    SELECT ID INTO auth_id from USER_STATUS us
      WHERE authorities = us.status;
    
    INSERT INTO USER (login, password, status_id)
      VALUES (userName, pword, auth_id);
  END;
